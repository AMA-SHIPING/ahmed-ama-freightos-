# AMA FreightOS V6 — Production Infrastructure Overlay

This package is the infrastructure layer intended to sit beneath AMA FreightOS V5.

It deliberately does **not** replace the V5 shipment domain, Workflow Desk, Operations Brain, AI router, or human approval model. It provides the production services those modules need:

```text
V5 FRONT DOOR / SHIPMENT DIGITAL TWIN / WORKFLOW ENGINE
                         │
                         ▼
                 V6 INFRASTRUCTURE
     ┌──────────────┬──────────────┬───────────────┐
     │ PostgreSQL   │ Auth / RBAC  │ Object Storage│
     │ persistence  │ sessions     │ S3-compatible │
     └──────────────┴──────────────┴───────────────┘
                         │
                 Redis + BullMQ
                         │
                         ▼
                Document worker pool
                         │
                         ▼
                  Audit / notifications
```

## What is implemented

- PostgreSQL migration for organizations, branches, users, branch access, sessions, audit events, stored objects, job records and notifications.
- Password hashing using Node.js `crypto.scrypt` with per-user salt.
- Signed HttpOnly session cookies backed by server-side session records. Session tokens are stored only as SHA-256 hashes in PostgreSQL.
- Role enforcement for OWNER, MANAGER, OPERATIONS, FINANCE, DOCUMENTATION and CUSTOMER.
- Strict organization scoping for document/job access.
- S3-compatible pre-signed upload/download URLs.
- Redis + BullMQ document-processing queue with retries and persistent job records.
- Audit events for authentication and object workflow operations.
- V5 integration adapter contract so the existing Operations Brain/workflow engine can be registered without duplicating decision logic.
- Graceful shutdown for API, worker and database connections.

## Important integration note

The V5 ZIP supplied in the previous response is not available as a mounted file in the current runtime. This package is therefore an **overlay**, not a claim of an already-merged V5/V6 repository.

To integrate:

1. Copy `src/` infrastructure modules into the V5 repository, preserving V5 domain modules.
2. Add these dependencies to the V5 `package.json` if not already present.
3. Wire `registerV5WorkflowEngine(...)` to the existing V5 deterministic workflow engine.
4. Point the V5 API routes that currently use local persistence at PostgreSQL repositories.
5. Run the migration before starting the API.
6. Run the API and worker as separate services/processes.

## Environment

Copy `.env.example` to `.env` and supply real values. Production `SESSION_SECRET` must be a long random value and must not be committed to git.

## Local bootstrap

```bash
npm install
npm run migrate
NEW_USER_PASSWORD='use-a-strong-password' npm run create-user -- owner@ama.local 'AMA Owner' OWNER '<organization-uuid>'
npm run dev
npm run worker
```

## Production service topology

Recommended minimum:

- `api`: one or more stateless API instances.
- `worker`: one or more document/background workers.
- `postgres`: managed PostgreSQL with automated backups and point-in-time recovery.
- `redis`: managed Redis compatible with BullMQ.
- `object-storage`: S3-compatible bucket with private-by-default policy.

The API can scale horizontally because authentication state is stored in PostgreSQL and jobs are externalized to Redis.

## Security controls included

- HttpOnly + SameSite cookies.
- Secure cookies automatically enabled in production.
- HMAC-signed session identifiers.
- No raw session token persisted to the database.
- Organization-scoped authorization checks on stored objects and jobs.
- Origin validation for state-changing browser requests.
- Audit logging of critical infrastructure actions.
- Secrets supplied through environment variables.

## Next vertical slice

After this overlay is integrated, the next feature should be one complete vertical slice:

```text
Shipment record
  → PostgreSQL repository
  → authenticated API
  → RBAC
  → audit event
  → Workflow Desk query
  → Operations Brain proposal
  → human approval
  → persisted action
  → notification
```

That slice should replace one V5 local/transient path end-to-end before adding another infrastructure feature.
