# ADR-001: Production infrastructure boundaries

Status: Proposed

## Decision

AMA FreightOS will separate business decisioning from infrastructure execution.

The V5 workflow engine remains the business-control plane. V6 provides durable persistence, authentication, authorization, storage, queues and auditability.

## Consequences

Positive:
- Business rules are not duplicated across worker processes.
- API instances can scale horizontally.
- Long-running work is resilient to API restarts.
- Critical actions remain human-reviewable.
- Organization and branch scoping can be enforced server-side.

Trade-offs:
- PostgreSQL and Redis become production dependencies.
- Deployment has multiple services instead of a single process.
- Schema migrations and operational monitoring become required.
