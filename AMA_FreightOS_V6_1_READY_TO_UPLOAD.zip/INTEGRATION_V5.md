# V5 → V6.1 integration contract

V6.1 is an infrastructure slice. V5 remains the owner of operational reasoning.

## 1. Register the V5 workflow engine at API startup

Create an adapter in the V5 repository that maps the existing Workflow Engine's output to this exact contract:

```ts
import { registerV5WorkflowEngine } from './integration/v5Adapter.js';

registerV5WorkflowEngine({
  async runOperationalSweep({ organizationId, shipments, now }) {
    const result = await existingV5WorkflowEngine.runOperationalSweep({ organizationId, shipments, now });
    return result.actions.map((action: any) => ({
      code: action.code,
      priority: action.priority, // P0 | P1 | P2
      title: action.title,
      rationale: action.rationale,
      shipmentId: action.shipmentId,
      recommendedAction: action.recommendedAction,
      actionType: action.actionType,
      payload: action.payload ?? {}
    }));
  },

  async executeApprovedAction(input) {
    await existingV5WorkflowEngine.executeApprovedAction(input);
  }
});
```

Do not duplicate the Operations Brain logic in V6. If the V5 engine is unavailable, a deterministic fallback can be enabled only for local development with `ALLOW_DETERMINISTIC_WORKFLOW_FALLBACK=true`.

## 2. Required V5 action semantics

`executeApprovedAction` must be idempotent for the supplied `actionId`. It must not silently mutate critical commercial or shipment records without writing its own domain event / audit event.

Recommended behavior:

```text
approval
  → V6 creates workflow_action(QUEUED)
  → V6 queues workflow.action.execute
  → V5 validates current shipment state
  → V5 performs allowed action or returns a controlled failure
  → V6 marks action EXECUTED / FAILED
```

## 3. First frontend integration

Replace the V5 local Workflow Desk datasource with:

- `GET /api/workflow/desk`
- `POST /api/workflow/sweep`
- `GET /api/workflow/proposals`
- `POST /api/workflow/proposals/:id/decision`
- `GET /api/notifications`

Shipment datasource:

- `GET /api/shipments`
- `GET /api/shipments/:id`
- `POST /api/shipments`

All requests must use the browser session cookie. Remove any legacy role headers from the browser.

## 4. Acceptance gates

A slice is integrated only when all of the following work against PostgreSQL:

1. Non-authenticated request → 401.
2. Cross-organization shipment lookup → 404.
3. Operations can create and view shipments but cannot approve proposals.
4. Owner/Manager can approve or reject proposals.
5. Repeating a decision on an already-decided proposal does not create a second action.
6. Approved action is persisted as `QUEUED` before worker execution.
7. Worker cannot execute without a registered V5 `executeApprovedAction` implementation.
8. Every critical action has an audit event.
9. Notifications are persisted and scoped to the organization/user.
10. A repeated workflow sweep does not create duplicate pending proposals for the same shipment/action code.
