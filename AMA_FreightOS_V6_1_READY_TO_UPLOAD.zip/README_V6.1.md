# AMA FreightOS V6.1 — Shipment Operations Vertical Slice

This release continues the V6 infrastructure overlay and adds the first end-to-end operational path.

```text
Shipment
  ↓
PostgreSQL
  ↓
Authenticated API + RBAC
  ↓
Workflow Desk
  ↓
V5 Operations Brain
  ↓
Human proposal review
  ↓
OWNER / MANAGER approval
  ↓
workflow_action = QUEUED
  ↓
Redis / BullMQ
  ↓
V5 executeApprovedAction()
  ↓
EXECUTED / FAILED
  ↓
Audit + notifications
```

## New capabilities

- Durable shipment records with organization isolation.
- Shipment creation, listing and detail APIs.
- PostgreSQL-backed shipment event history.
- Workflow Desk API with role-aware filtering.
- V5 workflow-engine adapter with strict decision contract.
- Development-only deterministic workflow fallback for ETA/customs/receivables signals.
- Persistent workflow proposals with duplicate-pending protection.
- Explicit human approval boundary.
- Durable queued workflow actions rather than pretending approval itself is execution.
- BullMQ action worker that requires the registered V5 execution bridge.
- Persistent notification feed.
- Audit records for shipment creation and workflow decisions/sweeps.

## Important boundary

This slice does **not** claim that shipment actions have been executed merely because a manager approves them. Approval creates a durable command in `workflow_actions` with status `QUEUED`. Real execution occurs only through the V5 `executeApprovedAction` bridge.

## Run locally

```bash
npm install
npm run migrate
npm test
npm run dev
npm run workflow-worker
```

Set `ALLOW_DETERMINISTIC_WORKFLOW_FALLBACK=true` only when testing the overlay without the real V5 engine. Keep it `false` in production.

## Production validation still required

This environment has no Docker runtime and the earlier package installation timed out. Therefore no claim is made here that the PostgreSQL, Redis, S3/MinIO, API and worker processes have been jointly smoke-tested in containers.
