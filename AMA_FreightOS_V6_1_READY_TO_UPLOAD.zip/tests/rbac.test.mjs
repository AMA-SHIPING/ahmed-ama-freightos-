import test from 'node:test';
import assert from 'node:assert/strict';

test('RBAC contract includes operational roles', () => {
  const roles = ['OWNER','MANAGER','OPERATIONS','FINANCE','DOCUMENTATION','CUSTOMER'];
  assert.ok(roles.includes('OWNER'));
  assert.ok(roles.includes('OPERATIONS'));
  assert.ok(roles.includes('FINANCE'));
});
