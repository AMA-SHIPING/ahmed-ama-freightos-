import test from 'node:test';
import assert from 'node:assert/strict';

function fallbackOperationalSweep(shipments, now = new Date()) {
  const results = [];
  for (const shipment of shipments) {
    if (shipment.eta && new Date(shipment.eta).getTime() < now.getTime() && !['DELIVERED','CANCELLED'].includes(shipment.status)) {
      results.push({ code: 'ETA_OVERDUE', priority: 'P0', shipmentId: shipment.id });
    }
    if (['PENDING_DOCUMENTS','UNDER_REVIEW','HOLD'].includes(shipment.customs_status)) {
      results.push({ code: 'CUSTOMS_BLOCKED', priority: 'P1', shipmentId: shipment.id });
    }
    if (shipment.receivable_due_date && new Date(shipment.receivable_due_date).getTime() < now.getTime() && Number(shipment.receivable_amount) > 0) {
      results.push({ code: 'RECEIVABLE_OVERDUE', priority: 'P2', shipmentId: shipment.id });
    }
  }
  return results;
}

test('workflow sweep produces deterministic P0/P1/P2 ordering signals', () => {
  const now = new Date('2026-10-03T15:00:00Z');
  const out = fallbackOperationalSweep([
    { id: 'S1', status: 'IN_TRANSIT', eta: '2026-10-01T00:00:00Z', customs_status: 'NOT_STARTED', receivable_due_date: null, receivable_amount: 0 },
    { id: 'S2', status: 'CUSTOMS', eta: '2026-10-10T00:00:00Z', customs_status: 'HOLD', receivable_due_date: null, receivable_amount: 0 },
    { id: 'S3', status: 'IN_TRANSIT', eta: null, customs_status: 'CLEARED', receivable_due_date: '2026-10-02T00:00:00Z', receivable_amount: 1000 }
  ], now);
  assert.deepEqual(out.map(x => x.code), ['ETA_OVERDUE','CUSTOMS_BLOCKED','RECEIVABLE_OVERDUE']);
  assert.deepEqual(out.map(x => x.priority), ['P0','P1','P2']);
});

test('delivered shipment does not generate overdue ETA action', () => {
  const out = fallbackOperationalSweep([{ id:'S4', status:'DELIVERED', eta:'2026-09-01T00:00:00Z', customs_status:'CLEARED', receivable_due_date:null, receivable_amount:0 }], new Date('2026-10-03T00:00:00Z'));
  assert.equal(out.length, 0);
});
