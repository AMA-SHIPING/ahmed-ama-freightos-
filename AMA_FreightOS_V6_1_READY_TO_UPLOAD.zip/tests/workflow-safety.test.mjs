import test from 'node:test';
import assert from 'node:assert/strict';

test('approved workflow action must enter a queued state before execution', () => {
  const statuses = ['QUEUED', 'EXECUTED', 'REJECTED', 'FAILED'];
  assert.ok(statuses.includes('QUEUED'));
  assert.equal(statuses.includes('AUTO_EXECUTED'), false);
});

test('only owner and manager may approve workflow proposals', () => {
  const canApprove = role => role === 'OWNER' || role === 'MANAGER';
  assert.equal(canApprove('OWNER'), true);
  assert.equal(canApprove('MANAGER'), true);
  assert.equal(canApprove('OPERATIONS'), false);
  assert.equal(canApprove('FINANCE'), false);
  assert.equal(canApprove('CUSTOMER'), false);
});
