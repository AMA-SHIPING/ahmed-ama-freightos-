import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

test('runtime supports scrypt used by password hashing', async () => {
  const password = 'A-long-production-password!';
  const salt = crypto.randomBytes(16).toString('base64url');
  const derived = await new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (err, key) => err ? reject(err) : resolve(key));
  });
  assert.equal(derived.length, 64);
});
