import { hashPassword } from '../src/auth/password.js';
import { db } from '../src/db/pool.js';

const [emailRaw, displayName, role, organizationId] = process.argv.slice(2);
const email = emailRaw?.trim().toLowerCase();
if (!email || !displayName || !role || !organizationId) {
  console.error('Usage: npm run create-user -- email displayName ROLE organizationId');
  process.exit(1);
}

const password = process.env.NEW_USER_PASSWORD;
if (!password) {
  console.error('Set NEW_USER_PASSWORD in the environment.');
  process.exit(1);
}

const passwordHash = await hashPassword(password);
await db.query(
  `INSERT INTO users(organization_id,email,display_name,password_hash,role)
   VALUES($1,$2,$3,$4,$5)
   ON CONFLICT (organization_id,email) DO UPDATE
   SET display_name = EXCLUDED.display_name, password_hash = EXCLUDED.password_hash,
       role = EXCLUDED.role, status = 'ACTIVE', updated_at = now()`,
  [organizationId, email, displayName, passwordHash, role]
);
console.log(`Upserted ${email} as ${role}`);
await db.end();
