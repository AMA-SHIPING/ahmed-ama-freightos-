import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import crypto from 'node:crypto';
import { env } from '../config/env.js';

export const s3 = new S3Client({
  region: env.s3Region,
  endpoint: env.s3Endpoint,
  forcePathStyle: env.s3ForcePathStyle,
  credentials: { accessKeyId: env.s3AccessKeyId, secretAccessKey: env.s3SecretAccessKey }
});

export function safeObjectKey(input: string): string {
  const normalized = input.replace(/[^a-zA-Z0-9._/-]/g, '_').replace(/\.\./g, '_');
  if (!normalized || normalized.startsWith('/')) throw new Error('Invalid object key');
  return normalized;
}

export async function createUploadUrl(objectKey: string, contentType: string): Promise<string> {
  const key = safeObjectKey(objectKey);
  const command = new PutObjectCommand({ Bucket: env.s3Bucket, Key: key, ContentType: contentType });
  return getSignedUrl(s3, command, { expiresIn: env.s3SignedUrlSeconds });
}

export async function createDownloadUrl(objectKey: string): Promise<string> {
  const command = new GetObjectCommand({ Bucket: env.s3Bucket, Key: safeObjectKey(objectKey) });
  return getSignedUrl(s3, command, { expiresIn: env.s3SignedUrlSeconds });
}

export async function deleteObject(objectKey: string): Promise<void> {
  await s3.send(new DeleteObjectCommand({ Bucket: env.s3Bucket, Key: safeObjectKey(objectKey) }));
}

export function sha256Hex(input: Buffer): string {
  return crypto.createHash('sha256').update(input).digest('hex');
}
