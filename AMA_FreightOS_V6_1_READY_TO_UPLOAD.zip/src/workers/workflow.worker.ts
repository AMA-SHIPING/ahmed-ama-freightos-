import { Worker, type Job } from 'bullmq';
import { redis } from '../queue/connection.js';
import { workflowQueueName, type WorkflowActionJob } from '../queue/workflowQueue.js';
import { getV5WorkflowEngine } from '../integration/v5Adapter.js';
import { db } from '../db/pool.js';

const worker = new Worker<WorkflowActionJob>(workflowQueueName, async (job: Job<WorkflowActionJob>) => {
  await db.query(`UPDATE workflow_actions SET status='QUEUED' WHERE id=$1 AND status='QUEUED'`, [job.data.actionId]);
  const engine = getV5WorkflowEngine();
  if (!engine.executeApprovedAction) throw new Error('V5 executeApprovedAction bridge is not registered');
  await engine.executeApprovedAction(job.data);
  await db.query(`UPDATE workflow_actions SET status='EXECUTED' WHERE id=$1`, [job.data.actionId]);
});

worker.on('failed', async (job, error) => {
  if (!job) return;
  await db.query(`UPDATE workflow_actions SET status='FAILED' WHERE id=$1`, [job.data.actionId]);
  console.error('Workflow action failed', job.data.actionId, error);
});

console.log(`AMA FreightOS workflow worker listening on ${workflowQueueName}`);
process.on('SIGTERM', () => void worker.close());
process.on('SIGINT', () => void worker.close());
