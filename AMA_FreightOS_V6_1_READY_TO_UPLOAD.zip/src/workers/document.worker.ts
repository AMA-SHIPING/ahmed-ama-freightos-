import { Worker } from 'bullmq';
import { redis } from '../queue/connection.js';
import { documentQueueName, type DocumentJob } from '../queue/documentQueue.js';
import { db } from '../db/pool.js';

const worker = new Worker<DocumentJob>(documentQueueName, async (job) => {
  const payload = job.data;
  await db.query('UPDATE job_records SET status = \'RUNNING\', attempts = attempts + 1, started_at = now() WHERE id = $1', [payload.jobRecordId]);

  try {
    // Infrastructure-safe baseline: verify the object/job contract and persist processing state.
    // Actual OCR/parser implementations plug into this worker by operation type.
    if (!payload.objectId || !payload.objectKey || !payload.organizationId) {
      throw new Error('Invalid document job payload');
    }

    const metadata = { operation: payload.operation, processedAt: new Date().toISOString() };
    await db.query(
      `UPDATE stored_objects
       SET status = CASE WHEN status = 'PENDING' THEN 'PROCESSED' ELSE status END,
           metadata = metadata || $2::jsonb,
           updated_at = now()
       WHERE id = $1 AND organization_id = $3`,
      [payload.objectId, JSON.stringify(metadata), payload.organizationId]
    );

    await db.query(
      `UPDATE job_records SET status = 'SUCCEEDED', finished_at = now(), error_message = NULL WHERE id = $1`,
      [payload.jobRecordId]
    );
  } catch (error) {
    await db.query(
      `UPDATE job_records SET status = 'FAILED', finished_at = now(), error_message = $2 WHERE id = $1`,
      [payload.jobRecordId, error instanceof Error ? error.message : 'Unknown worker error']
    );
    throw error;
  }
}, { connection: redis, concurrency: 4 });

worker.on('completed', (job) => console.log(`Document job completed: ${job.id}`));
worker.on('failed', (job, error) => console.error(`Document job failed: ${job?.id}`, error));

process.on('SIGTERM', async () => { await worker.close(); await redis.quit(); await db.end(); process.exit(0); });
process.on('SIGINT', async () => { await worker.close(); await redis.quit(); await db.end(); process.exit(0); });

console.log(`AMA FreightOS document worker listening on queue ${documentQueueName}`);
