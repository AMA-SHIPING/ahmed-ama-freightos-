import crypto from 'node:crypto';
import { db, withTransaction } from '../db/pool.js';
import { audit } from '../security/audit.js';
import type { ShipmentInput } from './types.js';

function cleanText(value: unknown, field: string, max = 500): string {
  const v = String(value ?? '').trim();
  if (!v) throw new Error(`${field} is required`);
  if (v.length > max) throw new Error(`${field} exceeds maximum length`);
  return v;
}

function nullableDate(value: unknown): string | null {
  if (value === undefined || value === null || value === '') return null;
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) throw new Error('Invalid date');
  return date.toISOString();
}

export async function createShipment(args: {
  organizationId: string;
  actorUserId: string;
  requestId?: string;
  ipAddress?: string | null;
  input: ShipmentInput;
}) {
  const input = args.input;
  const customerName = cleanText(input.customerName, 'customerName', 200);
  const customerEmail = input.customerEmail ? cleanText(input.customerEmail, 'customerEmail', 320).toLowerCase() : null;
  const origin = cleanText(input.origin, 'origin', 200);
  const destination = cleanText(input.destination, 'destination', 200);
  const cargoDescription = cleanText(input.cargoDescription, 'cargoDescription', 1000);
  const status = input.status ?? 'BOOKED';
  const customsStatus = input.customsStatus ?? 'NOT_STARTED';
  const branchCode = input.branchCode ? cleanText(input.branchCode, 'branchCode', 32) : null;
  const notes = input.notes ? cleanText(input.notes, 'notes', 3000) : null;
  const eta = nullableDate(input.eta);
  const receivableDueDate = nullableDate(input.receivableDueDate);

  if (input.receivableAmount !== undefined && (!Number.isFinite(input.receivableAmount) || input.receivableAmount < 0)) {
    throw new Error('receivableAmount must be a non-negative number');
  }
  if (input.quoteAmount !== undefined && input.quoteAmount !== null && (!Number.isFinite(input.quoteAmount) || input.quoteAmount < 0)) {
    throw new Error('quoteAmount must be a non-negative number');
  }

  const id = crypto.randomUUID();
  return withTransaction(async (client) => {
    const result = await client.query(
      `INSERT INTO shipments(
        id, organization_id, customer_name, customer_email, origin, destination,
        cargo_description, status, eta, customs_status, receivable_amount,
        receivable_currency, receivable_due_date, branch_code, quote_amount,
        quote_currency, notes, created_by, updated_by
      ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
      RETURNING *`,
      [id, args.organizationId, customerName, customerEmail, origin, destination, cargoDescription,
        status, eta, customsStatus, input.receivableAmount ?? 0, input.receivableCurrency ?? 'ETB',
        receivableDueDate, branchCode, input.quoteAmount ?? null, input.quoteCurrency ?? null,
        notes, args.actorUserId]
    );
    await client.query(
      `INSERT INTO shipment_events(id, organization_id, shipment_id, event_type, actor_user_id, payload)
       VALUES(gen_random_uuid(),$1,$2,'CREATED',$3,$4::jsonb)`,
      [args.organizationId, id, args.actorUserId, JSON.stringify({ status })]
    );
    await audit({ organizationId: args.organizationId, actorUserId: args.actorUserId, action: 'SHIPMENT_CREATED', resourceType: 'shipment', resourceId: id, requestId: args.requestId, ipAddress: args.ipAddress, metadata: { status, origin, destination } });
    return result.rows[0];
  });
}

export async function listShipments(organizationId: string) {
  const result = await db.query(
    `SELECT id, customer_name, customer_email, origin, destination, cargo_description, status,
            eta, customs_status, receivable_amount, receivable_currency, receivable_due_date,
            branch_code, quote_amount, quote_currency, notes, created_at, updated_at
     FROM shipments WHERE organization_id = $1 ORDER BY created_at DESC LIMIT 500`,
    [organizationId]
  );
  return result.rows;
}

export async function getShipment(organizationId: string, shipmentId: string) {
  const result = await db.query('SELECT * FROM shipments WHERE organization_id=$1 AND id=$2 LIMIT 1', [organizationId, shipmentId]);
  return result.rows[0] ?? null;
}

export async function listWorkflowShipments(organizationId: string) {
  const result = await db.query(
    `SELECT id, customer_name, origin, destination, status, eta, customs_status,
            receivable_amount, receivable_currency, receivable_due_date, branch_code,
            updated_at
     FROM shipments
     WHERE organization_id = $1 AND status NOT IN ('DELIVERED','CANCELLED')
     ORDER BY COALESCE(eta, '9999-12-31'::timestamptz), updated_at DESC`,
    [organizationId]
  );
  return result.rows;
}
