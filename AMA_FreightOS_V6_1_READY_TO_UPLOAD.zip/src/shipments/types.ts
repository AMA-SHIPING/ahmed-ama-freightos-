export type ShipmentStatus = 'INQUIRY' | 'QUOTED' | 'BOOKED' | 'IN_TRANSIT' | 'CUSTOMS' | 'DELIVERED' | 'CANCELLED';

export type ShipmentInput = {
  customerName: string;
  customerEmail?: string | null;
  origin: string;
  destination: string;
  cargoDescription: string;
  status?: ShipmentStatus;
  eta?: string | null;
  customsStatus?: 'NOT_STARTED' | 'PENDING_DOCUMENTS' | 'SUBMITTED' | 'UNDER_REVIEW' | 'CLEARED' | 'HOLD';
  receivableAmount?: number;
  receivableCurrency?: 'ETB' | 'RMB' | 'USD';
  receivableDueDate?: string | null;
  branchCode?: string | null;
  quoteAmount?: number | null;
  quoteCurrency?: 'ETB' | 'RMB' | 'USD' | null;
  notes?: string | null;
};
