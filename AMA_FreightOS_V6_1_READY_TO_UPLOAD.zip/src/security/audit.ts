import { db } from '../db/pool.js';

export async function audit(args: {
  organizationId: string;
  actorUserId?: string | null;
  action: string;
  resourceType?: string;
  resourceId?: string;
  requestId?: string;
  ipAddress?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  await db.query(
    `INSERT INTO audit_events(organization_id, actor_user_id, action, resource_type, resource_id, request_id, ip_address, metadata)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb)`,
    [
      args.organizationId,
      args.actorUserId ?? null,
      args.action,
      args.resourceType ?? null,
      args.resourceId ?? null,
      args.requestId ?? null,
      args.ipAddress ?? null,
      JSON.stringify(args.metadata ?? {})
    ]
  );
}
