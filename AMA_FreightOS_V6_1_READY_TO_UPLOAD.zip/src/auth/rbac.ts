import type { RequestHandler } from 'express';
import { getSessionUser, type AuthUser } from './session.js';

export const requireAuth: RequestHandler = async (req, res, next) => {
  try {
    const user = await getSessionUser(req);
    if (!user) {
      res.status(401).json({ ok: false, error: 'AUTH_REQUIRED' });
      return;
    }
    req.authUser = user;
    next();
  } catch (error) {
    next(error);
  }
};

export function requireRole(...roles: AuthUser['role'][]): RequestHandler {
  return (req, res, next) => {
    if (!req.authUser) {
      res.status(401).json({ ok: false, error: 'AUTH_REQUIRED' });
      return;
    }
    if (!roles.includes(req.authUser.role)) {
      res.status(403).json({ ok: false, error: 'FORBIDDEN' });
      return;
    }
    next();
  };
}

declare global {
  namespace Express {
    interface Request {
      authUser?: AuthUser & { sessionId: string };
    }
  }
}
