import crypto from 'node:crypto';

const N = 16384;
const r = 8;
const p = 1;
const keylen = 64;

export async function hashPassword(password: string): Promise<string> {
  if (password.length < 12) throw new Error('Password must be at least 12 characters');
  const salt = crypto.randomBytes(16).toString('base64url');
  const derived = await new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, keylen, { N, r, p, maxmem: 64 * 1024 * 1024 }, (error, key) => {
      if (error) reject(error); else resolve(key);
    });
  });
  return `scrypt$${N}$${r}$${p}$${salt}$${derived.toString('base64url')}`;
}

export async function verifyPassword(password: string, encoded: string): Promise<boolean> {
  const [scheme, nRaw, rRaw, pRaw, salt, expected] = encoded.split('$');
  if (scheme !== 'scrypt' || !nRaw || !rRaw || !pRaw || !salt || !expected) return false;
  const Nn = Number(nRaw), rr = Number(rRaw), pp = Number(pRaw);
  const derived = await new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, keylen, { N: Nn, r: rr, p: pp, maxmem: 64 * 1024 * 1024 }, (error, key) => {
      if (error) reject(error); else resolve(key);
    });
  });
  const expectedBuf = Buffer.from(expected, 'base64url');
  return expectedBuf.length === derived.length && crypto.timingSafeEqual(expectedBuf, derived);
}
