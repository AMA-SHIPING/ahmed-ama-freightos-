import type { WorkflowDecision } from '../workflow/types.js';

export type V5WorkflowEngine = {
  runOperationalSweep: (input: {
    organizationId: string;
    shipments: unknown[];
    now: string;
  }) => Promise<WorkflowDecision[]>;
  executeApprovedAction?: (input: {
    organizationId: string;
    shipmentId: string;
    actionType: WorkflowDecision['actionType'];
    payload: Record<string, unknown>;
    actionId: string;
  }) => Promise<void>;
};

let engine: V5WorkflowEngine | null = null;

export function registerV5WorkflowEngine(candidate: V5WorkflowEngine): void {
  engine = candidate;
}

export function hasV5WorkflowEngine(): boolean {
  return engine !== null;
}

export function getV5WorkflowEngine(): V5WorkflowEngine {
  if (!engine) throw new Error('V5 workflow engine is not registered');
  return engine;
}
