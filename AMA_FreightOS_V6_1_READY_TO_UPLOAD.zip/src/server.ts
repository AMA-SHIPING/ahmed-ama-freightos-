import { app } from './http/app.js';
import { env } from './config/env.js';
import { db } from './db/pool.js';

const server = app.listen(env.port, () => {
  console.log(`AMA FreightOS API listening on :${env.port}`);
});

async function shutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}; shutting down`);
  server.close(async () => {
    await db.end();
    process.exit(0);
  });
}

process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
