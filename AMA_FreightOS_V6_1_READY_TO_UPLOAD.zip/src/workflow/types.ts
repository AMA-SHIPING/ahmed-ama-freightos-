export type WorkflowPriority = 'P0' | 'P1' | 'P2';

export type WorkflowDecision = {
  code: string;
  priority: WorkflowPriority;
  title: string;
  rationale: string;
  shipmentId: string;
  recommendedAction: string;
  actionType: 'FOLLOW_UP' | 'CUSTOMS_ESCALATION' | 'PAYMENT_FOLLOW_UP' | 'SETTLEMENT_REVIEW' | 'MILESTONE_UPDATE';
  payload?: Record<string, unknown>;
};

export type WorkflowSweepResult = {
  generatedAt: string;
  decisions: WorkflowDecision[];
};
