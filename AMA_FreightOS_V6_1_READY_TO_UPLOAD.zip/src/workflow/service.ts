import { db, withTransaction } from '../db/pool.js';
import { audit } from '../security/audit.js';
import { getV5WorkflowEngine } from '../integration/v5Adapter.js';
import { listWorkflowShipments } from '../shipments/service.js';
import type { WorkflowDecision } from './types.js';
import { env } from '../config/env.js';
import { fallbackOperationalSweep, type WorkflowShipment } from './deterministic.js';
import { workflowQueue } from '../queue/workflowQueue.js';

const roleCanApprove = new Set(['OWNER', 'MANAGER']);

export async function createWorkflowSweep(args: {
  organizationId: string;
  actorUserId: string;
  requestId?: string;
  ipAddress?: string | null;
}) {
  const shipments = await listWorkflowShipments(args.organizationId);
  let decisions: WorkflowDecision[];
  try {
    const engine = getV5WorkflowEngine();
    decisions = await engine.runOperationalSweep({ organizationId: args.organizationId, shipments, now: new Date().toISOString() });
  } catch (error) {
    if (!env.allowDeterministicWorkflowFallback) throw error;
    decisions = fallbackOperationalSweep(shipments as WorkflowShipment[]);
  }

  for (const decision of decisions) {
    await db.query(
      `INSERT INTO workflow_proposals(
        organization_id, shipment_id, code, priority, title, rationale, recommended_action,
        action_type, payload, status, proposed_by
      ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,'PENDING',$10)
       ON CONFLICT DO NOTHING`,
      [args.organizationId, decision.shipmentId, decision.code, decision.priority, decision.title,
        decision.rationale, decision.recommendedAction, decision.actionType,
        JSON.stringify(decision.payload ?? {}), args.actorUserId]
    );
  }
  await audit({ organizationId: args.organizationId, actorUserId: args.actorUserId, action: 'WORKFLOW_SWEEP_RUN', resourceType: 'workflow_run', requestId: args.requestId, ipAddress: args.ipAddress, metadata: { shipmentCount: shipments.length, proposalCount: decisions.length } });
  return { generatedAt: new Date().toISOString(), shipmentCount: shipments.length, proposals: decisions.length };
}

export async function listPendingProposals(organizationId: string, limit = 100) {
  const result = await db.query(
    `SELECT p.*, s.customer_name, s.origin, s.destination, s.status AS shipment_status
     FROM workflow_proposals p JOIN shipments s ON s.id = p.shipment_id
     WHERE p.organization_id=$1 AND p.status='PENDING'
     ORDER BY CASE p.priority WHEN 'P0' THEN 0 WHEN 'P1' THEN 1 ELSE 2 END, p.created_at DESC
     LIMIT $2`, [organizationId, Math.min(limit, 200)]
  );
  return result.rows;
}

export async function decideProposal(args: {
  organizationId: string;
  actorUserId: string;
  actorRole: string;
  proposalId: string;
  decision: 'APPROVE' | 'REJECT';
  reason?: string | null;
  requestId?: string;
  ipAddress?: string | null;
}) {
  if (!roleCanApprove.has(args.actorRole)) throw new Error('Only OWNER or MANAGER can approve or reject workflow proposals');
  return withTransaction(async (client) => {
    const found = await client.query(
      `SELECT * FROM workflow_proposals WHERE id=$1 AND organization_id=$2 FOR UPDATE`, [args.proposalId, args.organizationId]
    );
    if (!found.rowCount) throw new Error('PROPOSAL_NOT_FOUND');
    const proposal = found.rows[0];
    if (proposal.status !== 'PENDING') return proposal;

    const status = args.decision === 'APPROVE' ? 'APPROVED' : 'REJECTED';
    const updated = await client.query(
      `UPDATE workflow_proposals SET status=$2, decision_by=$3, decision_at=now(), decision_reason=$4
       WHERE id=$1 RETURNING *`, [args.proposalId, status, args.actorUserId, args.reason ?? null]
    );

    await client.query(
      `INSERT INTO workflow_actions(id, organization_id, proposal_id, shipment_id, action_type, status, actor_user_id, payload)
       VALUES(gen_random_uuid(),$1,$2,$3,$4,$5,$6,$7::jsonb)
       ON CONFLICT (proposal_id) DO NOTHING RETURNING id`,
      [args.organizationId, args.proposalId, proposal.shipment_id, proposal.action_type,
        args.decision === 'APPROVE' ? 'QUEUED' : 'REJECTED', args.actorUserId, proposal.payload]
    );

    const actionResult = args.decision === 'APPROVE' ? await client.query('SELECT id FROM workflow_actions WHERE proposal_id=$1 LIMIT 1', [args.proposalId]) : { rows: [] };
    const actionId = actionResult.rows[0]?.id ?? null;

    await client.query(
      `INSERT INTO notifications(id, organization_id, user_id, severity, title, body)
       SELECT gen_random_uuid(), $1, u.id,
              CASE WHEN $3 = 'APPROVED' THEN 'INFO' ELSE 'P2' END,
              $4,
              $5
       FROM users u
       WHERE u.organization_id=$1 AND u.status='ACTIVE' AND u.role IN ('OWNER','MANAGER')`,
      [args.organizationId, args.proposalId, status, `Workflow proposal ${status.toLowerCase()}`,
        `${proposal.title} for shipment ${proposal.shipment_id} was ${status.toLowerCase()} by ${args.actorRole}.`]
    );

    if (args.decision === 'APPROVE' && actionId) {
      await workflowQueue.add('workflow.action.execute', {
        actionId, organizationId: args.organizationId, shipmentId: proposal.shipment_id,
        actionType: proposal.action_type, payload: proposal.payload
      });
    }

    await audit({ organizationId: args.organizationId, actorUserId: args.actorUserId, action: `WORKFLOW_PROPOSAL_${status}`, resourceType: 'workflow_proposal', resourceId: args.proposalId, requestId: args.requestId, ipAddress: args.ipAddress, metadata: { reason: args.reason ?? null, shipmentId: proposal.shipment_id, actionType: proposal.action_type } });
    return updated.rows[0];
  });
}
