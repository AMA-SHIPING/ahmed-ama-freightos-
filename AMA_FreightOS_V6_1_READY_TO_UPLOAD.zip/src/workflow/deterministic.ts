import type { WorkflowDecision } from './types.js';

export type WorkflowShipment = {
  id: string; customer_name: string; origin: string; destination: string; status: string;
  eta: string | null; customs_status: string; receivable_amount: string | number; receivable_currency: string;
  receivable_due_date: string | null;
};

function priority(level: 'overdue' | 'customs' | 'receivable'): WorkflowDecision['priority'] {
  if (level === 'overdue') return 'P0';
  if (level === 'customs') return 'P1';
  return 'P2';
}

export function fallbackOperationalSweep(shipments: WorkflowShipment[], now = new Date()): WorkflowDecision[] {
  const results: WorkflowDecision[] = [];
  for (const shipment of shipments) {
    if (shipment.eta && new Date(shipment.eta).getTime() < now.getTime() && !['DELIVERED','CANCELLED'].includes(shipment.status)) {
      results.push({ code: 'ETA_OVERDUE', priority: priority('overdue'), title: 'Shipment ETA is overdue', rationale: `ETA ${shipment.eta} has passed while shipment remains ${shipment.status}.`, shipmentId: shipment.id, recommendedAction: 'Open shipment, confirm current physical status and update milestone or escalation owner.', actionType: 'MILESTONE_UPDATE' });
    }
    if (['PENDING_DOCUMENTS','UNDER_REVIEW','HOLD'].includes(shipment.customs_status)) {
      results.push({ code: 'CUSTOMS_BLOCKED', priority: priority('customs'), title: 'Customs dependency requires attention', rationale: `Customs status is ${shipment.customs_status}.`, shipmentId: shipment.id, recommendedAction: 'Review missing customs dependency and assign an owner.', actionType: 'CUSTOMS_ESCALATION' });
    }
    if (shipment.receivable_due_date && new Date(shipment.receivable_due_date).getTime() < now.getTime() && Number(shipment.receivable_amount) > 0) {
      results.push({ code: 'RECEIVABLE_OVERDUE', priority: priority('receivable'), title: 'Receivable is overdue', rationale: `Outstanding ${shipment.receivable_currency} ${shipment.receivable_amount} passed its due date.`, shipmentId: shipment.id, recommendedAction: 'Finance follow-up and reconcile customer payment status.', actionType: 'PAYMENT_FOLLOW_UP' });
    }
  }
  return results;
}
