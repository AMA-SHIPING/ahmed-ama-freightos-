CREATE TABLE IF NOT EXISTS shipments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  customer_name text NOT NULL,
  customer_email text,
  origin text NOT NULL,
  destination text NOT NULL,
  cargo_description text NOT NULL,
  status text NOT NULL CHECK (status IN ('INQUIRY','QUOTED','BOOKED','IN_TRANSIT','CUSTOMS','DELIVERED','CANCELLED')),
  eta timestamptz,
  customs_status text NOT NULL CHECK (customs_status IN ('NOT_STARTED','PENDING_DOCUMENTS','SUBMITTED','UNDER_REVIEW','CLEARED','HOLD')),
  receivable_amount numeric(18,2) NOT NULL DEFAULT 0,
  receivable_currency char(3) NOT NULL CHECK (receivable_currency IN ('ETB','RMB','USD')),
  receivable_due_date timestamptz,
  branch_code text,
  quote_amount numeric(18,2),
  quote_currency char(3) CHECK (quote_currency IN ('ETB','RMB','USD')),
  notes text,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_shipments_org_status ON shipments(organization_id, status);
CREATE INDEX IF NOT EXISTS idx_shipments_org_eta ON shipments(organization_id, eta);
CREATE INDEX IF NOT EXISTS idx_shipments_org_customs ON shipments(organization_id, customs_status);

CREATE TABLE IF NOT EXISTS shipment_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  shipment_id uuid NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_shipment_events_shipment_time ON shipment_events(shipment_id, created_at DESC);

CREATE TABLE IF NOT EXISTS workflow_proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  shipment_id uuid NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  code text NOT NULL,
  priority text NOT NULL CHECK (priority IN ('P0','P1','P2')),
  title text NOT NULL,
  rationale text NOT NULL,
  recommended_action text NOT NULL,
  action_type text NOT NULL CHECK (action_type IN ('FOLLOW_UP','CUSTOMS_ESCALATION','PAYMENT_FOLLOW_UP','SETTLEMENT_REVIEW','MILESTONE_UPDATE')),
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  proposed_by uuid REFERENCES users(id) ON DELETE SET NULL,
  decision_by uuid REFERENCES users(id) ON DELETE SET NULL,
  decision_at timestamptz,
  decision_reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_workflow_proposals_org_status ON workflow_proposals(organization_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_workflow_proposals_shipment ON workflow_proposals(shipment_id, created_at DESC);

CREATE TABLE IF NOT EXISTS workflow_actions (
  id uuid PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  proposal_id uuid NOT NULL REFERENCES workflow_proposals(id) ON DELETE CASCADE,
  shipment_id uuid NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  action_type text NOT NULL,
  status text NOT NULL CHECK (status IN ('QUEUED','EXECUTED','REJECTED','FAILED')),
  actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (proposal_id)
);

CREATE OR REPLACE FUNCTION touch_shipments_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_shipments_updated_at ON shipments;
CREATE TRIGGER trg_shipments_updated_at BEFORE UPDATE ON shipments FOR EACH ROW EXECUTE FUNCTION touch_shipments_updated_at();

CREATE UNIQUE INDEX IF NOT EXISTS uq_pending_workflow_proposal ON workflow_proposals(organization_id, shipment_id, code) WHERE status='PENDING';
