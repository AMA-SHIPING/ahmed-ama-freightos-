import type { RequestHandler } from 'express';

export const cookieParserLite: RequestHandler = (req, _res, next) => {
  const header = req.headers.cookie ?? '';
  const cookies: Record<string, string> = {};
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx <= 0) continue;
    const key = part.slice(0, idx).trim();
    const value = decodeURIComponent(part.slice(idx + 1).trim());
    cookies[key] = value;
  }
  req.cookies = cookies;
  next();
};

declare global {
  namespace Express {
    interface Request {
      cookies?: Record<string, string>;
    }
  }
}
