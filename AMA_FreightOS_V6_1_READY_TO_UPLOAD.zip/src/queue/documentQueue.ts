import { Queue } from 'bullmq';
import { redis } from './connection.js';

export const documentQueueName = 'ama-document-processing';
export const documentQueue = new Queue(documentQueueName, {
  connection: redis,
  defaultJobOptions: {
    attempts: 5,
    backoff: { type: 'exponential', delay: 2_000 },
    removeOnComplete: 200,
    removeOnFail: 500
  }
});

export type DocumentJob = {
  jobRecordId: string;
  organizationId: string;
  objectId: string;
  objectKey: string;
  operation: 'INDEX_METADATA' | 'EXTRACT_TEXT' | 'RECONCILE';
};
