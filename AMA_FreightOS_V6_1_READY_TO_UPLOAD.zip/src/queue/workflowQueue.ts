import { Queue } from 'bullmq';
import { redis } from './connection.js';

export const workflowQueueName = 'ama-workflow-actions';
export const workflowQueue = new Queue(workflowQueueName, {
  connection: redis,
  defaultJobOptions: {
    attempts: 5,
    backoff: { type: 'exponential', delay: 2_000 },
    removeOnComplete: 500,
    removeOnFail: 1000
  }
});

export type WorkflowActionJob = {
  actionId: string;
  organizationId: string;
  shipmentId: string;
  actionType: 'FOLLOW_UP' | 'CUSTOMS_ESCALATION' | 'PAYMENT_FOLLOW_UP' | 'SETTLEMENT_REVIEW' | 'MILESTONE_UPDATE';
  payload: Record<string, unknown>;
};
