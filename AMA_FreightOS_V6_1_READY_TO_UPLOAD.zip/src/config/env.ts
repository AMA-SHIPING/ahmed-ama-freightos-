function required(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

function positiveInt(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number(raw);
  if (!Number.isInteger(value) || value <= 0) throw new Error(`${name} must be a positive integer`);
  return value;
}

export const env = {
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: positiveInt('PORT', 8080),
  appOrigin: required('APP_ORIGIN'),
  databaseUrl: required('DATABASE_URL'),
  redisUrl: required('REDIS_URL'),
  sessionSecret: required('SESSION_SECRET'),
  sessionTtlSeconds: positiveInt('SESSION_TTL_SECONDS', 8 * 60 * 60),
  cookieName: process.env.COOKIE_NAME ?? 'ama_freightos_sid',
  s3Endpoint: required('S3_ENDPOINT'),
  s3Region: process.env.S3_REGION ?? 'us-east-1',
  s3Bucket: required('S3_BUCKET'),
  s3AccessKeyId: required('S3_ACCESS_KEY_ID'),
  s3SecretAccessKey: required('S3_SECRET_ACCESS_KEY'),
  s3ForcePathStyle: (process.env.S3_FORCE_PATH_STYLE ?? 'false') === 'true',
  s3SignedUrlSeconds: positiveInt('S3_SIGNED_URL_SECONDS', 15 * 60),
  maxUploadBytes: positiveInt('MAX_UPLOAD_BYTES', 50 * 1024 * 1024),
  trustedProxy: (process.env.TRUSTED_PROXY ?? 'false') === 'true',
  allowDeterministicWorkflowFallback: (process.env.ALLOW_DETERMINISTIC_WORKFLOW_FALLBACK ?? 'false') === 'true'
};

if (env.sessionSecret.length < 32) {
  throw new Error('SESSION_SECRET must be at least 32 characters');
}
