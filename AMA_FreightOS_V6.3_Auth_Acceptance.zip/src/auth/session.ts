import crypto from 'node:crypto';
import type { Request, Response } from 'express';
import { db } from '../db/pool.js';
import { env } from '../config/env.js';

export type AuthUser = {
  id: string;
  organizationId: string;
  email: string;
  displayName: string;
  role: 'OWNER'|'MANAGER'|'OPERATIONS'|'FINANCE'|'DOCUMENTATION'|'CUSTOMER';
  status: 'ACTIVE'|'DISABLED';
};

type SessionRecord = AuthUser & { sessionId: string };

function hashToken(token: string): Buffer {
  return crypto.createHash('sha256').update(token).digest();
}

function signSessionId(sessionId: string): string {
  const signature = crypto.createHmac('sha256', env.sessionSecret).update(sessionId).digest('base64url');
  return `${sessionId}.${signature}`;
}

function verifyCookie(value: string): string | null {
  const [sessionId, signature, ...extra] = value.split('.');
  if (extra.length) return null;
  if (!sessionId || !signature) return null;
  const expected = crypto.createHmac('sha256', env.sessionSecret).update(sessionId).digest('base64url');
  if (signature.length !== expected.length) return null;
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected)) ? sessionId : null;
}

export async function createSession(user: AuthUser, req: Request, res: Response): Promise<void> {
  const rawToken = crypto.randomBytes(32).toString('base64url');
  const sessionId = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + env.sessionTtlSeconds * 1000);
  await db.query(
    `INSERT INTO sessions(id, user_id, token_hash, expires_at, ip_address, user_agent)
     VALUES($1,$2,$3,$4,$5,$6)`,
    [sessionId, user.id, hashToken(rawToken), expiresAt, req.ip || null, req.get('user-agent') || null]
  );
  const value = encodeURIComponent(signSessionId(`${sessionId}:${rawToken}`));
  const secure = env.nodeEnv === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${env.cookieName}=${value}; Max-Age=${env.sessionTtlSeconds}; Path=/; HttpOnly; SameSite=Lax${secure}`);
}

export async function getSessionUser(req: Request): Promise<SessionRecord | null> {
  const cookie = req.cookies?.[env.cookieName];
  if (!cookie) return null;
  const signed = verifyCookie(cookie);
  if (!signed) return null;
  const [sessionId, rawToken, ...extra] = signed.split(':');
  if (!sessionId || !rawToken || extra.length) return null;
  const result = await db.query(
    `SELECT s.id AS session_id, u.id, u.organization_id, u.email, u.display_name, u.role, u.status
     FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.id = $1 AND s.token_hash = $2 AND s.expires_at > now()`,
    [sessionId, hashToken(rawToken)]
  );
  if (!result.rowCount) return null;
  await db.query('UPDATE sessions SET last_seen_at = now() WHERE id = $1', [sessionId]);
  const row = result.rows[0];
  if (row.status !== 'ACTIVE') return null;
  return row as SessionRecord;
}

export async function destroySession(req: Request, res: Response): Promise<void> {
  const cookie = req.cookies?.[env.cookieName];
  if (cookie) {
    const signed = verifyCookie(cookie);
    if (signed) {
      const [sessionId] = signed.split(':');
      if (sessionId) await db.query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
  }
  const secure = env.nodeEnv === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${env.cookieName}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax${secure}`);
}
