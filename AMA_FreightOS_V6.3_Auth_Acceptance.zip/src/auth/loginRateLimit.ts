import crypto from 'node:crypto';
import { redis } from '../queue/connection.js';
import { env } from '../config/env.js';

function keyPart(value: string): string {
  return crypto.createHash('sha256').update(value).digest('hex').slice(0, 32);
}

export async function enforceLoginRateLimit(ip: string, email: string): Promise<{ allowed: boolean; retryAfterSeconds: number }> {
  const windowSeconds = env.loginRateLimitWindowSeconds;
  const limit = env.loginRateLimitPerWindow;
  const keys = [
    `ama:auth:ip:${keyPart(ip || 'unknown')}`,
    `ama:auth:email:${keyPart(email || 'unknown')}`,
  ];

  try {
    const pipeline = redis.multi();
    for (const key of keys) {
      pipeline.incr(key);
      pipeline.expire(key, windowSeconds, 'NX');
    }
    const results = await pipeline.exec();
    const counts = (results ?? [])
      .filter((item, index) => index % 2 === 0)
      .map(item => Number(item?.[1] ?? 0));
    const blocked = counts.some(count => count > limit);
    return { allowed: !blocked, retryAfterSeconds: blocked ? windowSeconds : 0 };
  } catch {
    // Fail closed for the auth boundary when the distributed limiter cannot be consulted.
    return { allowed: false, retryAfterSeconds: 30 };
  }
}

export async function clearLoginRateLimit(ip: string, email: string): Promise<void> {
  const keys = [
    `ama:auth:ip:${keyPart(ip || 'unknown')}`,
    `ama:auth:email:${keyPart(email || 'unknown')}`,
  ];
  try {
    await redis.del(...keys);
  } catch {
    // Login remains functional if cleanup fails.
  }
}
