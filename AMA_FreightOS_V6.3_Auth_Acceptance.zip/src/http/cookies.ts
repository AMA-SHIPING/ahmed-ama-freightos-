import type { RequestHandler } from 'express';

export const cookieParserLite: RequestHandler = (req, _res, next) => {
  const header = req.headers.cookie ?? '';
  const cookies: Record<string, string> = {};
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx <= 0) continue;
    const key = part.slice(0, idx).trim();
    try {
      cookies[key] = decodeURIComponent(part.slice(idx + 1).trim());
    } catch {
      // Ignore malformed cookie values rather than throwing out of the middleware.
    }
  }
  req.cookies = cookies;
  next();
};

declare global {
  namespace Express {
    interface Request {
      cookies?: Record<string, string>;
    }
  }
}
