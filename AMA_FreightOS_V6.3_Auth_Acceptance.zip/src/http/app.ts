import crypto from 'node:crypto';
import express from 'express';
import { env } from '../config/env.js';
import { db } from '../db/pool.js';
import { cookieParserLite } from './cookies.js';
import { requireAuth, requireRole } from '../auth/rbac.js';
import { createSession, destroySession, getSessionUser } from '../auth/session.js';
import { verifyPassword } from '../auth/password.js';
import { clearLoginRateLimit, enforceLoginRateLimit } from '../auth/loginRateLimit.js';
import { audit } from '../security/audit.js';
import { createDownloadUrl, createUploadUrl, safeObjectKey } from '../storage/objectStore.js';
import { documentQueue } from '../queue/documentQueue.js';
import { createShipment, getShipment, listShipments } from '../shipments/service.js';
import { decideProposal, listPendingProposals, createWorkflowSweep } from '../workflow/service.js';

const DUMMY_PASSWORD_HASH = 'scrypt$16384$8$1$lE9uTYaWmWGqS4KTtRmcmA$CX6VE8QYUy010SSY5udY_9w3vg0rmgYN6AfBNg4YMbPM-nteIOjZgaplrS1Q8BV_fluh-__-4NNSBVX-1EGyLw';

export const app = express();
app.set('trust proxy', env.trustedProxy);
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (env.nodeEnv === 'production') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
app.use(express.json({ limit: '2mb' }));
app.use(cookieParserLite);
app.use((req, res, next) => {
  const requestId = req.header('x-request-id') || crypto.randomUUID();
  req.requestId = requestId;
  res.setHeader('x-request-id', requestId);
  if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
    const origin = req.header('origin');
    if (origin && origin !== env.appOrigin) {
      res.status(403).json({ ok: false, error: 'ORIGIN_DENIED' });
      return;
    }
  }
  next();
});

app.get('/api/infra/health', async (_req, res, next) => {
  try {
    await db.query('SELECT 1');
    res.json({ ok: true, service: 'ama-freightos-api', database: 'ok', time: new Date().toISOString() });
  } catch (error) { next(error); }
});

app.post('/api/auth/login', async (req, res, next) => {
  try {
    const email = String(req.body?.email ?? '').trim().toLowerCase();
    const password = String(req.body?.password ?? '');
    if (!email || !password) { res.status(400).json({ ok: false, error: 'EMAIL_AND_PASSWORD_REQUIRED' }); return; }
    const rate = await enforceLoginRateLimit(req.ip || 'unknown', email);
    if (!rate.allowed) {
      res.setHeader('Retry-After', String(rate.retryAfterSeconds));
      res.status(429).json({ ok: false, error: 'LOGIN_RATE_LIMITED' });
      return;
    }
    const result = await db.query(
      `SELECT id, organization_id, email, display_name, password_hash, role, status
       FROM users WHERE email = $1 LIMIT 1`, [email]
    );
    const user = result.rows[0];
    const valid = await verifyPassword(password, user?.password_hash ?? DUMMY_PASSWORD_HASH);
    if (!user || user.status !== 'ACTIVE' || !valid) {
      res.status(401).json({ ok: false, error: 'INVALID_CREDENTIALS' });
      return;
    }
    await clearLoginRateLimit(req.ip || 'unknown', email);
    const authUser = { id: user.id, organizationId: user.organization_id, email: user.email, displayName: user.display_name, role: user.role, status: user.status } as const;
    await createSession(authUser, req, res);
    await audit({ organizationId: user.organization_id, actorUserId: user.id, action: 'AUTH_LOGIN', requestId: req.requestId, ipAddress: req.ip, metadata: {} });
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, user: { id: user.id, email: user.email, displayName: user.display_name, role: user.role } });
  } catch (error) { next(error); }
});

app.post('/api/auth/logout', async (req, res, next) => {
  try {
    const user = await getSessionUser(req);
    if (user) await audit({ organizationId: user.organizationId, actorUserId: user.id, action: 'AUTH_LOGOUT', requestId: req.requestId, ipAddress: req.ip });
    await destroySession(req, res);
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  const user = req.authUser!;
  res.setHeader('Cache-Control', 'no-store');
  res.json({ ok: true, user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role, organizationId: user.organizationId } });
});



app.post('/api/shipments', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','DOCUMENTATION'), async (req, res, next) => {
  try {
    const shipment = await createShipment({
      organizationId: req.authUser!.organizationId,
      actorUserId: req.authUser!.id,
      requestId: req.requestId,
      ipAddress: req.ip,
      input: req.body ?? {}
    });
    res.status(201).json({ ok: true, shipment });
  } catch (error) { next(error); }
});

app.get('/api/shipments', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','FINANCE','DOCUMENTATION'), async (req, res, next) => {
  try {
    const shipments = await listShipments(req.authUser!.organizationId);
    res.json({ ok: true, shipments });
  } catch (error) { next(error); }
});

app.get('/api/shipments/:id', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','FINANCE','DOCUMENTATION'), async (req, res, next) => {
  try {
    const shipment = await getShipment(req.authUser!.organizationId, req.params.id);
    if (!shipment) { res.status(404).json({ ok: false, error: 'SHIPMENT_NOT_FOUND' }); return; }
    res.json({ ok: true, shipment });
  } catch (error) { next(error); }
});

app.get('/api/workflow/desk', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','FINANCE','DOCUMENTATION'), async (req, res, next) => {
  try {
    const proposals = await listPendingProposals(req.authUser!.organizationId);
    const role = req.authUser!.role;
    const visible = role === 'FINANCE'
      ? proposals.filter((p: any) => p.action_type === 'PAYMENT_FOLLOW_UP' || p.action_type === 'SETTLEMENT_REVIEW')
      : role === 'OPERATIONS' || role === 'DOCUMENTATION'
        ? proposals.filter((p: any) => p.action_type !== 'PAYMENT_FOLLOW_UP' && p.action_type !== 'SETTLEMENT_REVIEW')
        : proposals;
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, role, proposals: visible });
  } catch (error) { next(error); }
});

app.post('/api/workflow/sweep', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS'), async (req, res, next) => {
  try {
    const result = await createWorkflowSweep({
      organizationId: req.authUser!.organizationId,
      actorUserId: req.authUser!.id,
      requestId: req.requestId,
      ipAddress: req.ip
    });
    res.status(201).json({ ok: true, ...result });
  } catch (error) { next(error); }
});

app.get('/api/workflow/proposals', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','FINANCE','DOCUMENTATION'), async (req, res, next) => {
  try {
    res.json({ ok: true, proposals: await listPendingProposals(req.authUser!.organizationId) });
  } catch (error) { next(error); }
});

app.post('/api/workflow/proposals/:id/decision', requireAuth, requireRole('OWNER','MANAGER'), async (req, res, next) => {
  try {
    const decision = String(req.body?.decision ?? '').toUpperCase();
    if (decision !== 'APPROVE' && decision !== 'REJECT') {
      res.status(400).json({ ok: false, error: 'DECISION_MUST_BE_APPROVE_OR_REJECT' });
      return;
    }
    const proposal = await decideProposal({
      organizationId: req.authUser!.organizationId,
      actorUserId: req.authUser!.id,
      actorRole: req.authUser!.role,
      proposalId: req.params.id,
      decision: decision as 'APPROVE' | 'REJECT',
      reason: req.body?.reason ? String(req.body.reason).slice(0, 2000) : null,
      requestId: req.requestId,
      ipAddress: req.ip
    });
    res.json({ ok: true, proposal });
  } catch (error) {
    if (error instanceof Error && error.message === 'PROPOSAL_NOT_FOUND') {
      res.status(404).json({ ok: false, error: 'PROPOSAL_NOT_FOUND' });
      return;
    }
    if (error instanceof Error && error.message.includes('Only OWNER or MANAGER')) {
      res.status(403).json({ ok: false, error: 'FORBIDDEN' });
      return;
    }
    next(error);
  }
});

app.get('/api/workflow/actions', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','FINANCE','DOCUMENTATION'), async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT id, proposal_id, shipment_id, action_type, status, actor_user_id, payload, created_at
       FROM workflow_actions WHERE organization_id=$1
       ORDER BY created_at DESC LIMIT 200`,
      [req.authUser!.organizationId]
    );
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, actions: result.rows });
  } catch (error) { next(error); }
});

app.get('/api/notifications', requireAuth, async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT id, severity, title, body, read_at, created_at
       FROM notifications WHERE organization_id=$1 AND (user_id IS NULL OR user_id=$2)
       ORDER BY created_at DESC LIMIT 100`,
      [req.authUser!.organizationId, req.authUser!.id]
    );
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, notifications: result.rows });
  } catch (error) { next(error); }
});

app.post('/api/documents/presign-upload', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','DOCUMENTATION'), async (req, res, next) => {
  try {
    const contentType = String(req.body?.contentType ?? 'application/octet-stream');
    const objectKey = safeObjectKey(String(req.body?.objectKey ?? ''));
    const url = await createUploadUrl(objectKey, contentType);
    const inserted = await db.query(
      `INSERT INTO stored_objects(organization_id, object_key, bucket, content_type, status, created_by)
       VALUES($1,$2,$3,$4,'PENDING',$5) RETURNING id, object_key, bucket, status`,
      [req.authUser!.organizationId, objectKey, env.s3Bucket, contentType, req.authUser!.id]
    );
    await audit({ organizationId: req.authUser!.organizationId, actorUserId: req.authUser!.id, action: 'OBJECT_UPLOAD_PRESIGNED', resourceType: 'stored_object', resourceId: inserted.rows[0].id, requestId: req.requestId, metadata: { objectKey, contentType } });
    res.json({ ok: true, object: inserted.rows[0], uploadUrl: url });
  } catch (error) { next(error); }
});

app.post('/api/documents/presign-download', requireAuth, async (req, res, next) => {
  try {
    const objectKey = safeObjectKey(String(req.body?.objectKey ?? ''));
    const found = await db.query('SELECT id FROM stored_objects WHERE organization_id = $1 AND object_key = $2 LIMIT 1', [req.authUser!.organizationId, objectKey]);
    if (!found.rowCount) { res.status(404).json({ ok: false, error: 'OBJECT_NOT_FOUND' }); return; }
    res.json({ ok: true, downloadUrl: await createDownloadUrl(objectKey) });
  } catch (error) { next(error); }
});

app.post('/api/documents/process', requireAuth, requireRole('OWNER','MANAGER','OPERATIONS','DOCUMENTATION'), async (req, res, next) => {
  try {
    const objectId = String(req.body?.objectId ?? '');
    const object = await db.query('SELECT id, object_key FROM stored_objects WHERE id = $1 AND organization_id = $2', [objectId, req.authUser!.organizationId]);
    if (!object.rowCount) { res.status(404).json({ ok: false, error: 'OBJECT_NOT_FOUND' }); return; }
    const jobRecord = await db.query(
      `INSERT INTO job_records(organization_id, queue_name, job_name, status, payload, created_by)
       VALUES($1,'ama-document-processing','document.process','QUEUED',$2::jsonb,$3)
       RETURNING id`,
      [req.authUser!.organizationId, 'document.process', JSON.stringify({ objectId, objectKey: object.rows[0].object_key }), req.authUser!.id]
    );
    const job = await documentQueue.add('document.process', {
      jobRecordId: jobRecord.rows[0].id,
      organizationId: req.authUser!.organizationId,
      objectId,
      objectKey: object.rows[0].object_key,
      operation: String(req.body?.operation ?? 'INDEX_METADATA')
    });
    await db.query('UPDATE job_records SET external_job_id = $2 WHERE id = $1', [jobRecord.rows[0].id, String(job.id)]);
    res.status(202).json({ ok: true, jobRecordId: jobRecord.rows[0].id, queueJobId: String(job.id) });
  } catch (error) { next(error); }
});

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({ ok: false, error: 'INTERNAL_SERVER_ERROR' });
});
