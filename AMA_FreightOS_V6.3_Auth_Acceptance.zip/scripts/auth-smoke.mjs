#!/usr/bin/env node
import assert from 'node:assert/strict';

const baseUrl = String(process.env.AMA_BASE_URL || '').replace(/\/$/, '');
const email = String(process.env.TEST_USER_EMAIL || '');
const password = String(process.env.TEST_USER_PASSWORD || '');
const otherOrgShipmentId = String(process.env.TEST_OTHER_ORG_SHIPMENT_ID || '');
const opsEmail = String(process.env.TEST_OPS_EMAIL || '');
const opsPassword = String(process.env.TEST_OPS_PASSWORD || '');
const proposalId = String(process.env.TEST_PROPOSAL_ID || '');

if (!baseUrl || !email || !password) {
  console.error('Required: AMA_BASE_URL TEST_USER_EMAIL TEST_USER_PASSWORD');
  process.exit(2);
}

function extractCookie(setCookie) {
  if (!setCookie) return null;
  return setCookie.split(';', 1)[0];
}

let cookie = null;
async function request(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (cookie) headers.set('cookie', cookie);
  const response = await fetch(`${baseUrl}${path}`, { ...options, headers, redirect: 'manual' });
  const setCookie = response.headers.get('set-cookie');
  if (setCookie) cookie = extractCookie(setCookie);
  let body = null;
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) body = await response.json();
  else body = await response.text();
  return { response, body };
}

async function main() {
  let out = await request('/api/auth/me');
  assert.equal(out.response.status, 401, 'Unauthenticated /api/auth/me must return 401');

  out = await request('/api/auth/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  assert.equal(out.response.status, 200, `Login failed: ${JSON.stringify(out.body)}`);
  assert.ok(cookie, 'Login must establish an auth cookie');

  out = await request('/api/auth/me');
  assert.equal(out.response.status, 200, 'Authenticated /api/auth/me must return 200');
  assert.ok(out.body?.user?.organizationId, 'Authenticated user must have an organizationId');
  const user = out.body.user;

  out = await request('/api/shipments');
  assert.ok([200, 403].includes(out.response.status), `Unexpected shipment list response: ${out.response.status}`);

  if (otherOrgShipmentId) {
    out = await request(`/api/shipments/${encodeURIComponent(otherOrgShipmentId)}`);
    assert.equal(out.response.status, 404, 'Cross-organization shipment lookup must return 404');
  }

  if (opsEmail && opsPassword && proposalId) {
    const savedCookie = cookie;
    let ops = await request('/api/auth/logout', { method: 'POST' });
    assert.equal(ops.response.status, 200);
    cookie = null;
    ops = await request('/api/auth/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email: opsEmail, password: opsPassword })
    });
    assert.equal(ops.response.status, 200, 'Operations test user login failed');
    ops = await request(`/api/workflow/proposals/${encodeURIComponent(proposalId)}/decision`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ decision: 'APPROVE', reason: 'AUTH_SMOKE_TEST' })
    });
    assert.equal(ops.response.status, 403, 'Operations user must not approve workflow proposals');
    cookie = savedCookie;
  }

  out = await request('/api/auth/logout', { method: 'POST' });
  assert.equal(out.response.status, 200, 'Logout must return 200');
  cookie = null;

  out = await request('/api/auth/me');
  assert.equal(out.response.status, 401, 'Session must be unusable after logout');

  console.log(JSON.stringify({
    ok: true,
    checks: ['unauthenticated_401', 'login_cookie', 'authenticated_me', 'shipment_scope', 'logout_revocation'],
    user: { role: user.role, organizationId: user.organizationId }
  }, null, 2));
}

main().catch(error => {
  console.error(error?.stack || error);
  process.exit(1);
});
